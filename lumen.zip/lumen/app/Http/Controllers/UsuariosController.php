<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Usuarios;
class UsuariosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $usuarios = Usuarios::all();
        return view('usuarios.index',['todosusuarios' => $usuarios]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('usuarios.create');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'nome' => 'required',
            'email' => 'required',
            'cargo' => 'required',
            'telefone' => 'required',
            'matricula' => 'required',
        ]);
        
        $usuarios = new Usuarios;
        $usuarios->nome = $request->nome;
        $usuarios->email = $request->email;
        $usuarios->cargo = $request->cargo;
        $usuarios->telefone = $request->telefone;
        $usuarios->matricula = $request->matricula;
        $usuarios->save();
        return redirect('usuarios')->with('message', 'Usuario atualizado com sucesso!');
        
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $usuarios = Usuarios::find($id);
        if(!$usuarios){
            abort(404);
        }
        return view('usuarios.details')->with('detailpage', $usuarios);        
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $usuarios = Usuarios::find($id);
        if(!$usuarios){
            abort(404);
        }
        return view('usuarios.edit')->with('detailpage', $usuarios);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'nome' => 'required',
            'email' => 'required',
            'cargo' => 'required',
            'telefone' => 'required',
            'matricula' => 'required',
        ]);
        
        $usuarios = Usuarios::find($id);
        $usuarios->nome = $request->nome;
        $usuarios->email = $request->email;
        $usuarios->cargo = $request->cargo;
        $usuarios->telefone = $request->telefone;
        $usuarios->matricula = $request->matricula;
        $usuarios->save();
        return redirect('usuarios')->with('message', 'Usuario editado com sucesso!');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $usuarios = Usuarios::find($id);
        $usuarios->delete();
        return redirect('usuarios')->with('message', 'Usuario apagado com sucesso!');
    }
}