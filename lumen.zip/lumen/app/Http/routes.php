<?php

/*...*/

route::get('/usuarios', 'UsuariosController@index');

route::group(['middleware' => 'web'], function() {
    route::get('/', 'HomeController@index');
    route::auth();
    route::get('/home', 'HomeController@index');
});