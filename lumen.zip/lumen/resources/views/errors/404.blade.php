<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Erro 404 - Não encontrado</title>
    </head>
    <body>
        <p>A página não foi encontrada!</p>
    </body>
</html>