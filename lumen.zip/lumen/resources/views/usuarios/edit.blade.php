<div class="principal">
    <h1><b>Editar Usuário</b></h1>
    <hr>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="/usuarios/{{ $detailpage->id }}" method="POST">
                    <div class="form-group row">
                        <label class="text-right col-sm-2 col-form-label">Nome:</label>
                        <div class="col-sm-10">
                            <input type="text" id="nome" name="nome" class="form-control" value="{{ $detailpage->nome }}" placeholder="Nome">
                            {{ ($errors->has('nome')) ? $errors->first('nome') : '' }}<br>
                        </div>
                    </div>                            
                    <div class="form-group row">
                        <label class="text-right col-sm-2 col-form-label">E-mail:</label>
                        <div class="col-sm-10">
                            <input type="text" id="email" name="email" class="form-control" value="{{ $detailpage->email }}" placeholder="Email">
                            {{ ($errors->has('email')) ? $errors->first('email') : '' }}<br>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="text-right col-sm-2 col-form-label">Cargo:</label>
                        <div class="col-sm-10">
                            <input type="text" id="cargo" name="cargo" class="form-control" value="{{ $detailpage->cargo }}" placeholder="Cargo">
                            {{ ($errors->has('cargo')) ? $errors->first('cargo') : '' }}<br>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="text-right col-sm-2 col-form-label">Telefone:</label>
                        <div class="col-sm-10">
                            <input type="text" id="telefone" name="telefone" class="form-control" value="{{ $detailpage->telefone }}" placeholder="Telefone" maxlength="15">
                            {{ ($errors->has('telefone')) ? $errors->first('telefone') : '' }}<br>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="text-right col-sm-2 col-form-label">Matrícula:</label>
                        <div class="col-sm-10">
                            <input type="text" id="matricula" name="matricula" class="form-control" value="{{ $detailpage->matricula }}" placeholder="Matrícula">
                            {{ ($errors->has('matricula')) ? $errors->first('matricula') : '' }}<br>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12">
                        	<input type="hidden" name="_method" value="put">
    						<input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <button type="submit" class="btn btn-default">Cadastrar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>