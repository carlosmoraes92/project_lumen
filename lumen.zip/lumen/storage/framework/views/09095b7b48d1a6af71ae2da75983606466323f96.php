<!DOCTYPE html>
    
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <title>Projeto - Sistema com Lumen</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <style>
            html, body {
                text-align: center;
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }
            table, thead, tbody, th, tr, td{
                text-align: center!important;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div style="max-width: 1500px; margin: 0 auto;" class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                    <div id="navbar" class="collapse navbar-collapse">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="/">Bem-Vindo</a></li>
                        </ul>
                    </div><!--/.nav-collapse -->
            </div><!--/.container-fluid -->
        </nav>
        <div class="container">
            <div class="pull-right col-md-12 nav navbar-nav">
                <p class="pull-right"><b class="text-success">Olá usuário!</b> Seja bem-vindo.</p>
            </div>
        </div>
        <?php echo e(Session::get('message')); ?>

        <div class="principal">
            <h1><b>Lista de Usuários</b></h1>
            <hr>
            <div class="container">
                <div class="container-fluid span12">
                    <div class="row">
                        <div class="col-md-12">
                            <?php $__currentLoopData = $todosusuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table class="table table-bordered table-inverse">
                                <tr>
                                    <th scope="row"><?php echo e($usuarios->nome); ?></th>
                                    <td><?php echo e($usuarios -> email); ?></td>
                                    <td><?php echo e($usuarios -> cargo); ?></td>
                                    <td><?php echo e($usuarios -> telefone); ?></td>
                                    <td><?php echo e($usuarios -> matricula); ?></td>
                                    <td>
                                        <a style="margin-bottom: 3px;" class="btn btn-info btn-block" name="editar" href="/usuarios/<?php echo e($usuarios->id); ?>/edit">Editar</a>
                                        <form action="/usuarios/<?php echo e($usuarios->id); ?>" method="POST">
                                            <input type="hidden" name="_method" value="delete">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-danger btn-block" name="name" value="Apagar">
                                        </form>
                                    </td>
                                </tr>
                            </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
    <script type="text/javascript">
    /* Máscaras ER */
    function mascara(o,f){
        v_obj=o
        v_fun=f
        setTimeout("execmascara()",1)
    }
    function execmascara(){
        v_obj.value=v_fun(v_obj.value)
    }
    function mtel(v){
        v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
        v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
        v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
        return v;
    }
    function id( el ){
        return document.getElementById( el );
    }
    window.onload = function(){
        id('phone').onkeypress = function(){
        mascara( this, mtel );
        }
    }        
    </script>
</html>