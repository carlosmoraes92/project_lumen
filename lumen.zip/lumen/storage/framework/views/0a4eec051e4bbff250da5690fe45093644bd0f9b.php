<div class="principal">
    <h1><b>Lista de Usuários</b></h1>
    <hr>
    <div class="container">
        <div class="container-fluid span12">
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-bordered table-inverse">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Cargo</th>
                                <th>Telefone</th>
                                <th>Matrícula</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo e($detailpage->nome); ?></th>
                                <td><?php echo e($detailpage->email); ?></td>
                                <td><?php echo e($detailpage->cargo); ?></td>
                                <td><?php echo e($detailpage->telefone); ?></td>
                                <td><?php echo e($detailpage->matricula); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<a href="/usuarios">Voltar</a>